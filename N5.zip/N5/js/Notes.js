let firestate = false, earthstate = false, waterstate = false, airstate = false;
function openTab(element) {
  if (element == "fire") {
      if (firestate == false) {
          document.getElementById("firesigns").style.height = "320px";
          firestate = true;
      }
      else if(firestate == true){
          document.getElementById("firesigns").style.height = "0px";
          firestate = false;
      }
  }
  if (element == ""){
      if (earthstate == false) {
          document.getElementById("earthsigns").style.height = "140px";
          earthstate = true;
      }
      else if(earthstate == true){
          document.getElementById("earthsigns").style.height = "0px";
          earthstate = false;
      }
  }
  if (element == ""){
      if (airstate == false) {
          document.getElementById("airsigns").style.height = "140px";
          airstate = true;
      }
      else if(airstate == true){
          document.getElementById("airsigns").style.height = "0px";
          airstate = false;
      }
  }
  if (element == ""){
      if (waterstate == false) {
          document.getElementById("watersigns").style.height = "140px";
          waterstate = true;
      }
      else if(waterstate == true){
          document.getElementById("watersigns").style.height = "0px";
          waterstate = false;
      }
  }
}

function unmute() {
     document.getElementById("music").play()
     document.getElementById("music").muted = false;
     document.getElementById("nooff").style.display = "block";
}
let slideIndex = 1;
let listIndex = 1;
showSlides(slideIndex);
showList(listIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function plusList(n){
  showList(listIndex += n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "block";  
}

function showList(n) {
  let i;
  let list = document.getElementsByClassName("myList");
  if (n > list.length) {listIndex = 1}    
  if (n < 1) {listIndex = list.length}
  for (i = 0; i < list.length; i++) {
    list[i].style.display = "none";  
  }
  list[listIndex-1].style.display = "block";  
}
function openNav() {
  document.getElementById("mySidenav").style.width = "300px";
  document.getElementById("main").style.marginLeft = "300px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}