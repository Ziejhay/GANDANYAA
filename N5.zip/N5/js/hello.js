let person = prompt("Please enter your name", "");
if (person != null) {
  document.getElementById("demo").innerHTML =
    "Hello! " + person + " ";
}

function myFunction() {
  var testV = 1;
  var pass1 = prompt('Hi! ' + person + ' Enter your password', ' ');
  while (testV < 3) {
    if (!pass1) history.go(-1);
    if (pass1.toLowerCase() == "ziejhay") {
      window.open('index.html');
      break;
    }
    testV += 1;
    var pass1 = prompt('Access Denied - Password Incorrect, Please Try Again.', 'Password');
  }
  if (pass1.toLowerCase() != "password" & testV == 3) history.go(-1);
  return " ";
}